<?php 

require("../../app.php");

use Techstore\Classes\Models\Order;

if ($request->getHas('id')){
    $id = $request->get('id');

    $ord = new Order;
    $ord->update("status = 'approved'", $id);

    $session->set('success', 'order approved');
    $request->redirectA("order.php?id=" . $id);
}