<?php

require_once("../../app.php");
use Techstore\Classes\Models\Product;

if($request->getHas('id')){
    $id = $request->get('id');

    $product = new Product;
    $imgName = $product->selectId($id, 'img')['img'];
    unlink(PATH . "uploads/$imgName");
    $product->delete($id);

    $session->set('seccess', 'product deleted successfully');
    $request->redirectA("products.php");
}