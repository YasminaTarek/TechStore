<?php

require_once("../../app.php");
use Techstore\Classes\Validation\Validator;
use Techstore\Classes\Models\Product;
use Techstore\Classes\File;

if ($request->postHas('submit')){
    $id = $request->post('id');
    $name = $request->post('name');
    $cat_id = $request->post('cat_id');
    $price = $request->post('price');
    $pieces_no = $request->post('pieces_no');
    $desc = $request->post('desc');
    $img = $request->files('img');

    //validation
    $validator = new Validator;
    $validator->validate('name', $name, ['required', 'str', 'max']);
    $validator->validate('cat_id', $cat_id, ['required', 'numeric']);
    $validator->validate('price', $price, ['required', 'numeric']);
    $validator->validate('pieces number', $pieces_no, ['required', 'numeric']);
    $validator->validate('description', $desc, ['required', 'str']);
    if($img['error'] == 0){
        $validator->validate('image', $img, ['image']);
    }
    
    if($validator->hasErrors()){
        $session->set("errors", $validator->getErrors());
        $request->redirectA("edit-product.php");
    }
    else {
        $product = new Product;
        $imgName = $product->selectId($id, 'img')['img'];

        if($img['error'] == 0){
            unlink(PATH . "uploads/$imgName");
            $file = new File($img);
            $imgName = $file->rename();
            $upload = $file->upload();
        }

        $product->update("name = '$name', `desc` = '$desc', price = '$price', pieces_no = '$pieces_no', cat_id = '$cat_id', img = '$imgName'", $id);
        $session->set('success', 'product updated successfully');
        $request->redirectA("products.php");
    }
}
else {
    $request->redirectA("edit-product.php");
}
