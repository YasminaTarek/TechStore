<?php

require_once("../../app.php");
use Techstore\Classes\Validation\Validator;
use Techstore\Classes\Models\Admin;

if($request->postHas('submit')){
    $name = $request->post('name');
    $email = $request->post('email');
    $password = $request->post('password');
    $confirm_password = $request->post('confirm_password');

    //validation
    $validator = new Validator;
    $validator->validate('name', $name, ['required', 'str', 'max']);
    $validator->validate('email', $email, ['required', 'email', 'max']);

    if(! empty($password) && ! $password == $confirm_password){
        $validator->validate('password', $password, ['required', 'str', 'max']);
    }
    
    if($validator->hasErrors()){
        $session->set("errors", $validator->getErrors());
        $request->redirectA("profile.php");
    }   
    else {
        $admin = new Admin;
        //update query with password
        if(! empty($password)){
            //password == confirmed password
            if($password == $confirm_password){
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $admin->update("name = '$name', email = '$email', `password` = '$hashedPassword'", $session->get('adminId'));
                $session->set('success', 'profile edited successfully');
                $request->redirectA("handlers/handle-logout.php");
            }
            //password != confirmed password
            else {
                $request->redirectA("profile.php");
                $session->set('failed', 'confirmed password is wrong');
            }
        }
        //update query without password
        else {
            $admin->update("name = '$name', email = '$email'", $session->get('adminId'));
            $session->set('success', 'profile edited successfully');
            $request->redirectA("handlers/handle-logout.php");
        }
    }
}
else {
    $request->redirectA("login.php");
}