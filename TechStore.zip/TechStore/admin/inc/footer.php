    <script src="<?= AURL; ?>assets/js/jquery-3.5.1.min.js"></script>
    <script src="<?= AURL; ?>assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>