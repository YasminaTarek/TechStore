<?php if($session->has('failed')): ?>
    <div class="alert alert-danger text-center">
        <?= $session->get('failed'); ?>
    </div>
<?php endif; $session->remove('failed'); ?>
