<?php 

//paths & urls
define("PATH",  __DIR__ . "/");
define("URL", "http://localhost/TechStore/");

define("APATH",  __DIR__ . "/admin/");
define("AURL", "http://localhost/TechStore/admin/");

//db credentials
define("DB_SERVERNAME",  "localhost");
define("DB_USERNAME",  "root");
define("DB_PASSWORD",  "");
define("DB_NAME",  "techstore");

//include classes
require_once(PATH . "vendor/autoload.php");

use Techstore\Classes\Request;
use Techstore\Classes\Session;

//objects
$request = new Request;
$session = new Session;