<?php

namespace Techstore\Classes\Models;
use Techstore\Classes\Db;

class Cat extends Db
{  
    public function __construct()
    {
        $this->table =  "cats";
        $this->connect();
    }
}