<?php

namespace Techstore\Classes\Validation;

class Numeric implements ValidationRule{
    public function check(string $name, $value)
    {
        if (! is_numeric($value)){
            return "$name must contains only numbers";
        }
        return false;
    }
}