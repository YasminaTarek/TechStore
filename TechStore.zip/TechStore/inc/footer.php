<?php require_once("app.php") ?>

	<!-- Copyright -->

    <div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col">
					
					<div class="copyright_container d-flex flex-sm-row flex-column align-items-center justify-content-start">
						<div class="copyright_content"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
                        </div>
						<div class="logos ml-sm-auto">
							<ul class="logos_list">
								<li><a href="#"><img src="<?= URL; ?>assets/images/logos_1.png" alt=""></a></li>
								<li><a href="#"><img src="<?= URL; ?>assets/images/logos_2.png" alt=""></a></li>
								<li><a href="#"><img src="<?= URL; ?>assets/images/logos_3.png" alt=""></a></li>
								<li><a href="#"><img src="<?= URL; ?>assets/images/logos_4.png" alt=""></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>

<script src="<?= URL; ?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?= URL; ?>assets/css/bootstrap4/popper.js"></script>
<script src="<?= URL; ?>assets/css/bootstrap4/bootstrap.min.js"></script>
<script src="<?= URL; ?>assets/plugins/greensock/TweenMax.min.js"></script>
<script src="<?= URL; ?>assets/plugins/greensock/TimelineMax.min.js"></script>
<script src="<?= URL; ?>assets/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="<?= URL; ?>assets/plugins/greensock/animation.gsap.min.js"></script>
<script src="<?= URL; ?>assets/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="<?= URL; ?>assets/plugins/slick-1.8.0/slick.js"></script>
<script src="<?= URL; ?>assets/plugins/easing/easing.js"></script>
<script src="<?= URL; ?>assets/plugins/Isotope/isotope.pkgd.min.js"></script>
<script src="<?= URL; ?>assets/plugins/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="<?= URL; ?>assets/plugins/parallax-js-master/parallax.min.js"></script>
<script src="<?= URL; ?>assets/js/custom.js"></script>
<script src="<?= URL; ?>assets/js/shop_custom.js"></script>
<script src="<?= URL; ?>assets/js/product_custom.js"></script>
<script src="<?= URL; ?>assets/js/cart_custom.js"></script>
</body>

</html>